$(function () {
  $('.btn-more').click(function () {
    Modal.normal({
      title:'',
      content:'<img src="../img/rule_bg.png" class="rule-bg">'
    });
  });
})